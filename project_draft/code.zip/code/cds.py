class cds:

    def disease_diagnosis(self, symptom_list):
        disease = "diabetes"

        # Todo import trained model
        model = "read trained model"

        # Todo read symptom_list pass it to trained model - determine the output and return the cds guess
        # disease = model.predict(symptom_list)

        return disease
