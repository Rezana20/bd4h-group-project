# This is a sample Python script.
import csv
import data_transformer


def patient_similarity():
    print("Module 3 CDS")


def diagnosis():
    print("Module 2 testing")


def data_preprocessing():
    print("Module 1, data pre-processing")
    # data_trans = data_transformer.data_transformer()

    # print("Fold0 pre-processing.....")
    # data_trans.read_fold("Fold0")

    # print("Fold1 pre-processing.....")
    # data_trans.read_fold("Fold1")
    #
    # print("Fold2 pre-processing.....")
    # data_trans.read_fold("Fold2")
    #
    # print("Fold3 pre-processing.....")
    # data_trans.read_fold("Fold3")
    #
    # print("Fold4 pre-processing.....")
    # data_trans.read_fold("Fold4")
    #
    # print("Fold5 pre-processing.....")
    # data_trans.read_fold("Fold5")
    #
    # print("Fold6 pre-processing.....")
    # data_trans.read_fold("Fold6")
    #
    # print("Fold7 pre-processing.....")
    # data_trans.read_fold("Fold7")
    #
    # print("Fold8 pre-processing.....")
    # data_trans.read_fold("Fold8")
    #
    # print("Fold9 pre-processing.....")
    # data_trans.read_fold("Fold9")


if __name__ == '__main__':
    # data_preprocessing()

    # diagnosis()

    patient_similarity()

    # print("Create the sample symptoms diagnosis object")
    #
    # symptom_diagnosis_list = data_trans.create_symptoms_diagnosis_training_data()
    #
    # print("create corpus file from all input sentences")
    # data_trans.create_sent2vec_input_corpus(symptom_diagnosis_list)

    # print("Create admissions mapping")
    # admissions_map = {}
    # admissions_map.update({sample_symptom.hadm_id: sample_symptom.symptoms})
    # print(admissions_map)
    #
    # list_of_symptoms = sample_symptom.symptoms.split(",")
    #
    # print(list_of_symptoms)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
