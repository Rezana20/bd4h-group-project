
class Symptom:

    def __init__(self, icd9_code, short_title):
        self.icd9_code = icd9_code
        self.short_title = short_title
